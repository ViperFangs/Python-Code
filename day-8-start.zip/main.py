# Review: 
# Create a function called greet(). 
# Write 3 print statements inside the function.
# Call the greet() function and run your code.


def greet():
  print("Hello!")
  print("Welcome to the greet function.")
  print("Making functions is actually super easy!")

def printnum(var):
  print(f"The thing you just put in is on the console is: {var}" )

greet()
any_word = input("\nEnter something and I will remember: ")

printnum(any_word)