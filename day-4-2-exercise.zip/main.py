 # Split string method
names_string = input("Give me everybody's names, separated by a comma. ")
names = names_string.split(", ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
import random

#len() will start counting from 1, but we index from 0 so we need to subtract 1
last_index = len(names)-1
random_person = random.randint(0,last_index)

print(f"{names[random_person]} is going to buy the meal today!")
