#Write your code below this row 👇

even_total = 0

#we need 101 instead of 100 as the complier only checks for lower_value < upper_value
for i in range(0,101,2):
  even_total += i

print(even_total)