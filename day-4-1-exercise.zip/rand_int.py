import random

heads_or_tails = random.randint(0,1)