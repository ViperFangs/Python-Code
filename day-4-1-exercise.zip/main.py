#Write your code below this line 👇
#Hint: Remember to import the random module first. 🎲

import rand_int

if rand_int.heads_or_tails == 0:
  print("Tails")
else:
  print("Heads")








