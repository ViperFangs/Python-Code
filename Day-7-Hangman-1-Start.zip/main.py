#Step 1 
import random

word_list = ["aardvark", "baboon", "camel"]

#TODO-1 - Randomly choose a word from the word_list and assign it to a variable called chosen_word.

chosen_word = random.choice(word_list)

#TODO-2 - Ask the user to guess a letter and assign their answer to a variable called guess. Make guess lowercase.
i=0
user_answer = []
for n in range(0, len(chosen_word)):
  user_answer.insert(n,"_")
  
while i == 0:
  guess = input("Type one character guess: ")
  guess_lower = guess.lower()

#TODO-3 - Check if the letter the user guessed (guess) is one of the letters in the     chosen_word.
  n=0
  for n in range(0, len(chosen_word)):
    if(chosen_word[n] == guess_lower):
      user_answer[n] = guess_lower
  
  print(user_answer)