# 🚨 Don't change the code below 👇
year = int(input("Which year do you want to check? "))
# 🚨 Don't change the code above 👆

#Write your code below this line 👇

Leap_4    =  float(year % 4)
Leap_100  =  float(year % 100)
Leap_400  =  float(year % 400)
leapyear = False

if (Leap_4 == 0):
  if (Leap_100 != 0):
    leapyear = True
  else:
    if(Leap_400 == 0):
      leapyear = True

if(leapyear == True):
  print("Leap year.")
else:
  print("Not leap year.")
