rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
import random


print("Welcome to Rock, Paper, Scissors!")

hand_set = [rock,paper,scissors]
game_output = random.randint(0,2)
status = "NULL"

print("The computer has decided it's move, it's your turn!")
user_choice = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors.\n"))

if game_output == 0 and user_choice == 0:
  status = "D"
elif game_output == 0 and user_choice == 1:
  status = "W"
elif game_output == 0 and user_choice == 2:
  status = "L"
elif game_output == 1 and user_choice == 0:
  status = "L"
elif game_output == 1 and user_choice == 1:
  status = "D"
elif game_output == 1 and user_choice == 2:
  status = "W"
elif game_output == 2 and user_choice == 0:
  status = "W"  
elif game_output == 2 and user_choice == 1:
  status = "L"
elif game_output == 2 and user_choice == 2:
  status = "D"
else:
  print("Invalid Choice!")

print("You selected: \n" + hand_set[user_choice] + "\n")
print("Computer Selected: \n" + hand_set[game_output] + "\n")

if(status == "W"):
  print("You Win :)")
elif(status == "L"):
  print("You Lose :(")
elif(status == "D"):
  print("It's a Draw!")
  